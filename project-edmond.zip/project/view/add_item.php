<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Item</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <style type="text/css">
    	#add_button
    	{
    		width: 100%;
    	}
    	.text-info
    	{
    		text-align: center;
    		float: left;
    	}
         #back-btn
        {
            text-decoration: none;
            color: white;
            width: 100%;
        }
        #back-link
        {
            text-decoration: none;
            color: white;
        }
        #logout-btn
        {
            text-decoration: none;
            color: white;
            width: 100%; 
        }
    </style>
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	
	<br><br>
	

     <form  action="../controller/add_item.ck.php" method="POST">
     	<center><h4>Add Item(s)</h4></center>
         <div class="row">
            <div class="col-md-2">
                <button class="btn btn-info" id="back-btn">
                    <span class="fa fa-arrow-left"></span>&nbsp;&nbsp;&nbsp;<a href="dashboard.php" id="back-link">Back</a></button>
            </div>
            <div class="col-md-8"></div>
            <div class="col-md-2">
                <button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
                    <a href="../controller/logout.ck.php" id="back-link">Logout</a>
                </button>
            </div>
        </div>
     	<br>
     	<?php

         // Check for global variables

         if( isset($_GET['error']) )
         {

         	if($_GET['error'] == "emptyfields")
         	{
         		print('<center><label class="text-danger">Fill in all fields!</label><br>');
         	}
         	if($_GET['error'] == "invaliditemname")
         	{
         		print('<center><label class="text-danger">Item name is invalid!</label><br>');
         	}
         	if($_GET['error'] == "invalidspecification")
         	{
         		print('<center><label class="text-danger">Item specification is invalid!</label><br>');
         	}
         	if($_GET['error'] == "invaliddescription")
         	{
         		print('<center><label class="text-danger">Item description is invalid!</label><br>');
         	}
         	if($_GET['error'] == "invalidquantity")
         	{
         		print('<center><label class="text-danger">Invalid item quantity!</label><br>');
         	}
         	if($_GET['error'] == "invalidunit_price")
         	{
         		print('<center><label class="text-danger">Invalid unit price!</label><br>');
         	}
         	if($_GET['error'] == "low_qty")
         	{
         		print('<center><label class="text-danger">Quantity must be atleast 1!</label><br>');
         	}

         }

         if( isset($_GET['msg']) )
         {
         	if($_GET['msg'] == "itemadded")
         	{
         		print('<center><label class="text-success">Item added sucessfully!</label><br>');
         	}


         }


     	?>

     	<br><br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info">Item Name</label></div>
     		<div class="col-md-6"><input type="text" name="name" class="form-control" required=""></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info">Specification</label></div>
     		<div class="col-md-6"><input type="text" name="specification" class="form-control" required=""></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info">Description</label></div>
     		<div class="col-md-6"><textarea class="form-control" name="description" rows="5" required=""></textarea></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info">Quantity</label></div>
     		<div class="col-md-6"><input type="text" name="quantity" class="form-control" required=""></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info">Unit Price</label></div>
     		<div class="col-md-6"><input type="text" name="unit-price" class="form-control" required=""></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"></div>
     		<div class="col-md-6">
     			<button type="submit" class="btn btn-primary" id="add_button" name="submit"><span class="fa fa-plus-circle" ></span>&nbsp;&nbsp;Add Item</button>
     		</div>
     	</div>



     </form>



	





	
</div> <!--Container ends here-->
</center>

<script src="../resources/bootstrap/js/jquery.min.js"></script>
<script src="../resources/bootstrap/js/popper.min.js"></script>
<script src="../resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>