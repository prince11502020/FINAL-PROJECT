<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Maintenace</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <style type="text/css">
    	 #back-btn
        {
            text-decoration: none;
            color: white;
            width: 100%;
        }
        #back-link
        {
            text-decoration: none;
            color: white;
        }
        #logout-btn
        {
            text-decoration: none;
            color: white;
            width: 100%; 
        }
    </style>
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	
	<br>
	 <div class="row">
            <div class="col-md-2">
                <button class="btn btn-info" id="back-btn">
                    <span class="fa fa-arrow-left"></span>&nbsp;&nbsp;&nbsp;<a href="dashboard.php" id="back-link">Back</a></button>
            </div>
            <div class="col-md-8"></div>
            <div class="col-md-2">
                <button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
                    <a href="../controller/logout.ck.php" id="back-link">Logout</a>
                </button>
            </div>
        </div>
	<div class="row">
		<div class="col-md-3 bg-warning">

			<div class="row">
				<div class="col-md-12"><h3 ><label style="float: left;">Dashboard</label></h3></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12"><label style="float: left;">Maintenance Schedule</label></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12"><label style="float: left;">Repair Computer</label></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12"><label style="float: left;">Sell Computer</label></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12"><label style="float: left;">Buy Computer</label></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12"><label style="float: left;">Spare Parts</label></div>
			</div>
			<br>
			<br>

		</div>

		<div class="col-md-9 bg-info">
			
			<div class="row">
				<div class="col-md-12">Maintenance Schedule</div>
			</div>



		</div>
	</div>

















	
</div> <!--Container ends here-->
</center>

<script src="../resources/bootstrap/js/jquery.min.js"></script>
<script src="../resources/bootstrap/js/popper.min.js"></script>
<script src="../resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>