<?php 
session_start();

$id = $first_name = $last_name = "";

$id         = $_SESSION['user_id'];   
$first_name = $_SESSION['first_name'];
$last_name  = $_SESSION['last_name'];

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">

    <style type="text/css">
    	.dashboard
    	{
    		font-size: 19px;
    		text-align: left;
    		color: white;
    	}
    	.dash_links
    	{
    		color: white;
    	}

    	body 
    	{
    		margin:0px;
    		font-family: Arial;
    	}

		#box 
		{
			height: 150px;
			padding: 10px;
			margin: 5px;
			background: khaki;
			border-radius: 25px;
			text-align: center;
		}
		#profile-pic
		{
			border-radius: 100%;
			height: 100%;
			width: 10%;
		}
		#logout-btn
		{
			float: right;
			border-radius: 5px;
		}
		#search-box
		{
			border-radius: 50px 50px 50px 50px;
			font-size: 12px;
			width: 250px;
			height: 36px;
			border-color: lightblue;
			text-align: center;
		}
		#search-icon
		{
		 font-size: 20px;
		 color: blue;
		}
		#search-icon:hover
		{
		 font-size: 20px;
		 color: lightblue;
		}
		.dash_links:hover
		{
			color: black;
			text-decoration: none;
		}
		.statistics
		{
			color: rgb(162,127,231);
		}
		#fundi
		{
			color: rgb(162,127,231);
			font-style: bold, italic;
			float: left;
		}
		.footer
		{
			font-size: 16px;
			text-align: left;
		}
		#fundi-title
		{
			color: rgb(162,127,231);
			font-size: 35px;
		}
    </style>


</head>

<body>

	<br><br>
<center>
<div class="container">
	<center><h5 id="fundi-title">COMPUTER SHOP IMS</h5></center>

	<br>
	<div class="row">
		<div class="col-md-3"><h5 id="fundi"><span class="fa fa-align-justify"></span>&nbsp;&nbsp;<b>FundiSoft</b></h5></div>
		<div class="col-md-4">
			<form class="form-search">
			        <input type="text" class="input-medium search-query" id="search-box" placeholder=" &nbsp;&nbsp;&nbsp;&nbsp;Search">
			        &nbsp;&nbsp;&nbsp;
			        <a href="#" type="submit"  name="search" id="search-icon"><span class="fa fa-search" ></span></a>
			</form>
		</div>
		<div class="col-md-5">
			<img src="../images/brian.jpg" id="profile-pic"> &nbsp;&nbsp;&nbsp;
			<?php 
			if(empty($first_name) || empty($last_name))
			{
				print('<label class="text-warning">Not logged in</label>');
			} else
			{
				print('<label class="text-dark">'.$first_name.' '.$last_name.'</label>');
			}
			 ?>
			
				<button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
					<a href="../controller/logout.ck.php" style="color: white; text-decoration: none;">Logout</a>
				</button>
			
		</div>
	</div>
	
	
	<div class="row">
		<div class="col-md-3 " style="background-color: rgb(162,127,231);">
			<br>

			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fas fa-home"></span>&nbsp; &nbsp;Dashboard</div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-cogs"></span>&nbsp; &nbsp;<a href="maintenance.php" class="dash_links">Maintenance Schedule</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-wrench"></span>&nbsp; &nbsp;<a href="repair_item.php" class="dash_links">Repair Items</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-cart-arrow-down"></span>&nbsp; &nbsp;<a href="sell_item.php" class="dash_links">Sell Items</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-cart-plus">&nbsp; &nbsp;</span><a href="buy_item.php" class="dash_links">Buy Items</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-sitemap"></span>&nbsp; &nbsp;<a href="view_items.php" class="dash_links">View Items</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-sitemap"></span>&nbsp; &nbsp;<a href="view_customers.php" class="dash_links">View Customers</a></div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12 dashboard" ><span class="fa fa-plus-circle"></span>&nbsp; &nbsp;<a href="add_item.php" class="dash_links">Add Item</a></div>
			</div>
			<br>
			<br>
			<br>

		</div>

		<div class="col-md-9 ">
			<h6><label style="float: left; color: rgb(162,127,231); ">Dashboard</label></h6>
			<br>
			<?php require("../controller/dashboard_statistics.ck.php"); ?>
			<br>
			<div class="row">

				<div class="col-sm- 1 col-md-1 col-lg-1"></div>
				<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
					<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4" id="box">
						<span class="statistics"><h3><b> <?php echo $sold_items ?> </b></h3> <br><h5>Sold items</h5></span>
					</div>
		 		</div>

		 		<div class="col-sm- 1 col-md-1 col-lg-1"></div>
				<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
					<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4 " id="box">
						<span class="statistics"><h3><b>  <?php echo $bought_items ?> </b></h3> <br><h5>Bought items</h5></span>
					</div>
				</div>

				<div class="col-sm- 1 col-md-1 col-lg-1"></div>
	    		<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
	    			<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4" id="box">
						<span class="statistics"><h3><b>  <?php echo $repaired_items ?> </b> </h3><br><h5>Repaired items</h5></span>
					</div>
	    		</div>
	        </div>

	        <br>
			<div class="row">

				<div class="col-sm- 1 col-md-1 col-lg-1"></div>
				<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
					<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4" id="box">
						<span class="statistics"><h3><b>  <?php echo $added_items ?> </b></h3> <br><h5>Added items</h5></span>
					</div>
		 		</div>

		 		<div class="col-sm- 1 col-md-1 col-lg-1"></div>
				<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
					<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4 " id="box">
						<span class="statistics"><h3><b>  <?php echo $customers ?> </b></h3> <br><h5>Customers</h5></span>
					</div>
				</div>

				<div class="col-sm- 1 col-md-1 col-lg-1"></div>
	    		<div class="col-sm-3 col-md-4 m-0 col-lg-3 p-2"> 
	    			<div class="d-flex flex-grow-1 flex-column align-items-center justify-content-center p-4" id="box">
						<span class="statistics"><h3><b> <?php echo $sellers ?> </b> </h3><br><h5>Sellers</h5></span>
					</div>
	    		</div>
	        </div>

	        <br>


		</div>
	</div>







<footer class="footer">
	<span>Developer: Mawanda Edmond</span><br>
	<span>PrinceSoft </span> Copyright&nbsp;&copy; &nbsp; 2020  &nbsp;&nbsp;
	<br>
	<span>All rights reserved</span>
</footer>
</div> <!--Container ends here-->
</center>

<script src="../resources/bootstrap/js/jquery.min.js"></script>
<script src="../resources/bootstrap/js/popper.min.js"></script>
<script src="../resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>