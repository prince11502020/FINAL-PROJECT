<?php session_start(); ?>
<?php
$connect = mysqli_connect("localhost", "root", "", "fundibook");
$query = "SELECT * FROM added_items ORDER BY id ";
$result = mysqli_query($connect, $query);
?>


<!DOCTYPE html>
<html>
<head>
	<title>View Items</title>
  
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
          <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>            
    <script src="../jquery/jquery.tabledit.min.js"></script>
    <style type="text/css">
       #back-btn
        {
            text-decoration: none;
            color: white;
            width: 100%;
        }
        #back-link
        {
            text-decoration: none;
            color: white;
        }
        #logout-btn
        {
            text-decoration: none;
            color: white;
            width: 100%; 
        }
    </style>
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	
	<br>
	
	        <div class="table-responsive">  
    <h3 align="center">Added Items</h3><br /> 
     <div class="row">
            <div class="col-md-2">
                <button class="btn btn-info" id="back-btn">
                    <span class="fa fa-arrow-left"></span>&nbsp;&nbsp;&nbsp;<a href="dashboard.php" id="back-link">Back</a></button>
            </div>
            <div class="col-md-8"></div>
            <div class="col-md-2">
                <button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
                    <a href="../controller/logout.ck.php" id="back-link">Logout</a>
                </button>
            </div>
        </div> 
    <table id="editable_table" class="table table-bordered table-striped">
     <thead>
      <tr>
       <th>ID</th>
       <th>Name</th>
       <th>Specification</th>
       <th>Description</th>
       <th>Quantity</th>
       <th>Unit Price</th>
       <th>Total Price</th>
       <th>Date Added</th>
      </tr>
     </thead>
     <tbody>
     <?php
     while($row = mysqli_fetch_array($result))
     {
      echo '
      <tr>
       <td>'.$row["id"].'</td>
       <td>'.$row["name"].'</td>
       <td>'.$row["specification"].'</td>
       <td>'.$row["description"].'</td>
       <td>'.$row["quantity"].'</td>
       <td>'.$row["unit_price"].'</td>
       <td>'.$row["total_price"].'</td>
       <td>'.$row["date_added"].'</td>
      </tr>
      ';
     }
     ?>
     </tbody>
    </table>
   </div>  
  </div>  
 </body>  
</html>  
<script>  
$(document).ready(function(){  
     $('#editable_table').Tabledit({
      url:'../controller/items_action.php',
      columns:{
       identifier:[0, "id"],
       editable:[[1, 'name'], [2, 'specification'], [3, 'description'], [4, 'quantity'], [5, 'unit_price'], [6, 'total_price'], [7, 'date_added']]
      },
      restoreButton:false,
      onSuccess:function(data, textStatus, jqXHR)
      {
       if(data.action == 'delete')
       {
        $('#'+data.id).remove();
       }
      }
     });
 
});  
 </script>