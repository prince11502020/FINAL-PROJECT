<?php session_start(); ?>
<?php require("../model/db.php");

    $record_per_page = 5;
    $page = "";

    if(isset($_GET['page']))
    {
        $page = $_GET['page'];
    }
    else
    {
        $page = 1;
    }

    $start_from = ($page - 1) * $record_per_page;

    try 
    {
        
        $query = "SELECT * FROM bought_items ORDER BY id LIMIT $start_from, $record_per_page";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $results = $stmt->get_result();


    } 
    catch (Exception $e) 
    {
        print("Error is: ".$e->getMessage());
        exit();
    }



 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Sell Item</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <style type="text/css">
    	#add_button, #reset_button
    	{
    		width: 100%;
    	}
    	.lbl
    	{
    		text-align: center;
    		float: left;
    	}
        #form
        {
            width: 60%;
        }
        #back-btn
        {
            text-decoration: none;
            color: white;
            width: 100%;
        }
        #back-link
        {
            text-decoration: none;
            color: white;
        }
        #logout-btn
        {
            text-decoration: none;
            color: white;
            width: 100%; 
        }
    </style>
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	<br>
    <b><center><h4>Sell Bought Items</h4></center></b>
        <br>
        <div class="row">
            <div class="col-md-2">
                <button class="btn btn-info" id="back-btn">
                    <span class="fa fa-arrow-left"></span>&nbsp;&nbsp;&nbsp;<a href="dashboard.php" id="back-link">Back</a></button>
            </div>
            <div class="col-md-8"></div>
            <div class="col-md-2">
                <button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
                    <a href="../controller/logout.ck.php" id="back-link">Logout</a>
                </button>
            </div>
        </div>
        <br>
        <label><a href="sell_item.php">Sell Added items instead</a></label>
    <div class="table-responsive">
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
            </tr>
            <?php 
            while($row = $results->fetch_assoc())
            {
            ?>

            <tr>
                        <td> <?php echo $row['id']; ?> </td>
                        <td> <?php echo $row['name']; ?> </td>
                        <td> <?php echo $row['quantity']; ?> </td>
                        <td> <?php echo $row['unit_price']; ?> </td>
            </tr>

            <?php 

             } 

             ?>



            
        </table>

        <div align="center">
            <label>Pages</label>
            <?php 
            try 
            {
                       $total_records = 0;
                        $page_query = "SELECT * FROM bought_items ORDER BY id DESC";
                        $stmt = $conn->prepare($page_query);
                        $stmt->execute();
                        $page_results = $stmt->get_result();
                        $total_records = $page_results->num_rows;
                        $total_pages = ceil($total_records / $record_per_page);

                        for($i= 1; $i <= $total_pages; $i++)
                        {

                            echo "<a href='sell_bought_items.php?page=".$i." '>&nbsp;".$i."&nbsp;</a>";
                        }


            } 
            catch (Exception $e) 
            {
               print("Error is: ".$e->getMessage());
               exit(); 
            }


             ?>

        </div>
        <form action="../controller/sell_bought_items.ck.php" method="POST">
            <?php 

            if(isset($_GET['error']))
            {

                if($_GET['error'] == "emptyfields")
                {
                    print("<p class='text-danger'>Empty fields</p>");

                }
                if($_GET['error'] == "invalidid")
                {

                    print("<p class='text-danger'>Invalid item ID</p>");
                }
                if($_GET['error'] == "invalidqty")
                {
                    print("<p class='text-danger'>Invalid item quantity</p>");

                }
                 if($_GET['error'] == "invalidprice")
                {
                    print("<p class='text-danger'>Invalid item price</p>");

                }
                 if($_GET['error'] == "noitem")
                {

                    print("<p class='text-danger'>Item not found</p>");
                }
                 if($_GET['error'] == "notenoughitems")
                {

                    print("<p class='text-danger'>Only a few items exist!</p>");
                }
                 if($_GET['error'] == "invaliditemqty")
                {

                    print("<p class='text-danger'>Atleast 1 item must be chosen for sale</p>");
                }
                 if($_GET['error'] == "invalidunitprice")
                {

                    print("<p class='text-danger'>Unit price is invalid</p>");
                }
                if($_GET['error'] == "invalidfname")
                {

                    print("<p class='text-danger'>Customers first name is invalid</p>");
                }
                 if($_GET['error'] == "invalidlname")
                {

                    print("<p class='text-danger'>Customers last name is invalid</p>");
                }
                 if($_GET['error'] == "invalidcontact")
                {

                    print("<p class='text-danger'>Customers contact is invalid</p>");
                }



            }
            else
            {

                if(isset($_GET['msg']) == "salessuccess")
                {
                    print("<h4 class='text-success'><span class='fa fa-check'></span>&nbsp;&nbsp;&nbsp;&nbsp;Sales complete! </h4>");
                }

            }


             ?>
            <div class="row">
                <div class="col-md-3">
                    <label>Item ID</label>
                    <input type="text" name="item-id"class="form-control" placeholder="Item ID here" required=""></input>
                </div>
                <div class="col-md-3">
                    <label>Quantity</label>
                    <input type="text" name="item-quantity" class="form-control" placeholder="Item quantity here" required=""></input>
                </div>
                <div class="col-md-3">
                    <label>Unit Price</label>
                    <input type="text" name="unit-price" class="form-control" placeholder="Unit price here" required=""></input>
                </div>
                <div class="col-md-3">
                   <label>Reset fields</label> <br>
                    <input type="reset" class="btn btn-warning" name="sell-item" style="width: 100%;">
                </div>
            </div>
            <br>
            <label class="text-warning"><b>Customer's Details</b></label>
            <div class="row">
                <div class="col-md-3">
                    <label>First name </label>
                    <input type="text" name="first-name"class="form-control" placeholder="First name" required=""></input>
                </div>
                <div class="col-md-3">
                    <label>Last name</label>
                    <input type="text" name="last-name" class="form-control" placeholder="Last name" required=""></input>
                </div>
                <div class="col-md-3">
                    <label>Contact</label>
                    <input type="text" name="contact" class="form-control" placeholder="Contact" required=""></input>
                </div>
                <div class="col-md-3">
                    <label>Confirm sell</label> <br>
                    <input type="submit" class="btn btn-info" name="sell-item" style="width: 100%;">
                </div>
            </div>
        </form>
        
        <br>


    </div>

	




	
</div> <!--Container ends here-->

</center>
<br>
<br>
<script src="../resources/bootstrap/js/jquery.min.js"></script>
<script src="../resources/bootstrap/js/popper.min.js"></script>
<script src="../resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>