<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Repair Item</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <style type="text/css">
    	#add_button, #reset_button
    	{
    		width: 100%;
    	}
    	.lbl
    	{
    		text-align: center;
    		float: left;
    	}
        #form
        {
            width: 60%;
        }
         #back-btn
        {
            text-decoration: none;
            color: white;
            width: 100%;
        }
        #back-link
        {
            text-decoration: none;
            color: white;
        }
        #logout-btn
        {
            text-decoration: none;
            color: white;
            width: 100%; 
        }
    </style>
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	
	<br>
	

     <form  action="../controller/repair_item.ck.php" method="POST" id="form">
     	<center><h4>Repair Item(s)</h4></center>
         <div class="row">
            <div class="col-md-2">
                <button class="btn btn-info" id="back-btn">
                    <span class="fa fa-arrow-left"></span>&nbsp;&nbsp;&nbsp;<a href="dashboard.php" id="back-link">Back</a></button>
            </div>
            <div class="col-md-8"></div>
            <div class="col-md-2">
                <button type="submit" name="logout" class="btn btn-danger" id="logout-btn" >
                    <a href="../controller/logout.ck.php" id="back-link">Logout</a>
                </button>
            </div>
        </div>
     	<br>
        <?php 

        if(isset($_GET['error']))
        {
            if($_GET['error'] == "emptyfields")
            {
                print("<p class='text-danger'>Empty fields</p>");
            }
             if($_GET['error'] == "invaliddescription")
            {
                print("<p class='text-danger'>Invalid description</p>");
            }
             if($_GET['error'] == "invalidquantity")
            {
                print("<p class='text-danger'>Invalid quantity</p>");
            }
             if($_GET['error'] == "invalidrepaircost")
            {
                print("<p class='text-danger'>Invalid repair cost</p>");
            }
             if($_GET['error'] == "invalidfname")
            {
                print("<p class='text-danger'>Invalid customer first name</p>");
            }
             if($_GET['error'] == "invalidlname")
            {
                print("<p class='text-danger'>Invalid customer last name</p>");
            }
             if($_GET['error'] == "invalidcontact")
            {
                print("<p class='text-danger'>Invalid contact</p>");
            }


        }
        else
        {

            if(isset($_GET['msg']))
            {


                
            }


        }


         ?>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info lbl">Item Name</label></div>
     		<div class="col-md-6"><input type="text" name="name" class="form-control"></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info lbl">Description</label></div>
     		<div class="col-md-6"><textarea class="form-control" name="description" rows="5"></textarea></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info lbl">Quantity</label></div>
     		<div class="col-md-6"><input type="text" name="quantity" class="form-control"></div>
     	</div>
     	<br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3"><label class="text-info lbl">Repair Costs</label></div>
     		<div class="col-md-6"><input type="text" name="repair-costs" class="form-control"></div>
     	</div>
     	<br>
        
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3"><label class="text-warning lbl">Customer's details:</label></label></div>
            <div class="col-md-6"></div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3"><label class="text-info lbl">First name</label></div>
            <div class="col-md-6"><input type="text" name="cust-fname" class="form-control"></div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3"><label class="text-info lbl">Last name</label></div>
            <div class="col-md-6"><input type="text" name="cust-lname" class="form-control"></div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3"><label class="text-info lbl">Contact</label></div>
            <div class="col-md-6"><input type="text" name="contact" class="form-control"></div>
        </div>
        <br>
     	<div class="row">
     		<div class="col-md-3"></div>
     		<div class="col-md-3">
                <button type="reset" class="btn btn-warning" id="reset_button">&nbsp;&nbsp;Reset</button>
            </div>
     		<div class="col-md-6">
     			<button type="submit" class="btn btn-primary" name="submit" id="add_button"><span class="fa fa-check" ></span>&nbsp;&nbsp;Done</button>
     		</div>
     	</div>



     </form>



	

















	
</div> <!--Container ends here-->

</center>
<br>
<br>
<script src="../resources/bootstrap/js/jquery.min.js"></script>
<script src="../resources/bootstrap/js/popper.min.js"></script>
<script src="../resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>