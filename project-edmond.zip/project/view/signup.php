<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	<link rel="stylesheet" type="text/css" href="../resources/bootstrap/css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="../resources/fontawesome/css/all.min.css">
<link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	<br>

	<form action="../controller/signup.ck.php" method="POST" class="frm">
		<div class="row">
			<div class="col-md-12"><h4>Signup</h4></div>
		</div>
		<br>
		<?php 

		if(isset($_GET['error']))
		{

			if($_GET['error'] == "emptyfields")
			{
				print("<p class='text-danger'>Fill in all fields</p>");
			}
			if($_GET['error'] == "invalidfname")
			{
				print("<p class='text-danger'>Invalid first name</p>");
			}
			if($_GET['error'] == "invalidlname")
			{
				print("<p class='text-danger'>Invalid last name</p>");
			}
			if($_GET['error'] == "invalidemail")
			{
				print("<p class='text-danger'>Invalid email</p>");
			}
			if($_GET['error'] == "invalidcontact")
			{
				print("<p class='text-danger'>Invalid contact</p>");
			}
			if($_GET['error'] == "invalidgender")
			{
				print("<p class='text-danger'>Invalid gender</p>");
			}
			if($_GET['error'] == "pswnotmatch")
			{
				print("<p class='text-danger'>Passwords do not match</p>");
			}


		}
		else
		{

			if(isset($_GET['msg']) == "regerror")
				{
				print("<p class='text-info'>There was a slight error logging you in!</p>");
			}


		}















		 ?>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">First Name</span></div>
			<div class="col-md-6"><input type="text" class="form-control" name="fname" placeholder="First name" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Last Name</span></div>
			<div class="col-md-6"><input type="text" class="form-control" name="lname" placeholder="Last name" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Gender</span></div>
			<div class="col-md-6">
				<input type="radio" name="gender" value="Male"><label for="male-gender">&nbsp;&nbsp;Male</label>
				&nbsp;&nbsp;&nbsp;
				<input type="radio" name="gender" value="Female"><label for="female-gender">&nbsp;&nbsp;Female</label>
				&nbsp;&nbsp;&nbsp;
				<input type="radio" name="gender" value="Others"><label for="other-gender">&nbsp;&nbsp;Others</label>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Email</span></div>
			<div class="col-md-6"><input type="text" class="form-control" name="email" placeholder="Email" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Contact</span></div>
			<div class="col-md-6"><input type="text" class="form-control" name="contact" placeholder="Contact" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Password</span></div>
			<div class="col-md-6"><input type="Password" class="form-control" name="password" placeholder="Password" required=""></div>
		</div>
		<br>
		<br>
		<div class="row">
			<div class="col-md-6"><span style="float: right; font-size: 14px; font-style: bold; font-family: Arial;">Confirm Password</span></div>
			<div class="col-md-6"><input type="Password" class="form-control" name="repeat-password" placeholder="Repeat Password" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<button type="submit" name="signup" class="form-control button btn-primary">
					<span class="fa fa-check"></span>&nbsp;&nbsp;&nbsp;&nbsp;Submit
				</button>
			</div>
		</div>
		<a href="../index.php">Already have an account? Click here to Login!</a>







	</form>

















	
</div> <!--Container ends here-->
</center>

<script src="resources/bootstrap/js/jquery.min.js"></script>
<script src="resources/bootstrap/js/popper.min.js"></script>
<script src="resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>