<?php 



$server = "localhost";
$username = "root";
$password = "";
$db = "fundibook";

$conn = new mysqli($server, $username, $password, "fundibook");

if($conn->connect_error)
{
	die("Connection failed: ".$conn->connect_error);
}


 