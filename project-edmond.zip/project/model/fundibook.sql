-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2020 at 08:42 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fundibook`
--

-- --------------------------------------------------------

--
-- Table structure for table `added_items`
--

CREATE TABLE `added_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `specification` text NOT NULL,
  `description` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `added_items`
--

INSERT INTO `added_items` (`id`, `name`, `specification`, `description`, `quantity`, `unit_price`, `total_price`, `date_added`) VALUES
(1, 'Dell', 'Fast', 'Excellent', 2, 400000, 800000, '2020-03-15 19:14:20'),
(2, 'HP ProBook', 'An iSeven computer', 'It is slim nice and portable', 10, 900000, 9000000, '2020-03-18 13:41:01'),
(3, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:41:48'),
(4, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:41:52'),
(5, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:41:54'),
(6, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:41:56'),
(7, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:41:58'),
(8, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:01'),
(9, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:03'),
(10, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:05'),
(11, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:07'),
(12, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:09'),
(13, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:12'),
(14, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:14'),
(15, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:17'),
(16, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:20'),
(17, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:22'),
(18, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:23'),
(19, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:26'),
(20, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:28'),
(21, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:39'),
(22, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:41'),
(23, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:43'),
(24, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:45'),
(25, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:48'),
(26, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:50'),
(27, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:52'),
(28, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:54'),
(29, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:42:57'),
(30, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:00'),
(31, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:03'),
(32, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:05'),
(33, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:07'),
(34, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:09'),
(35, 'Optical Mouse', 'Dell', 'Nice functionality', 4, 5000, 25000, '2020-03-18 13:43:11'),
(36, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:13'),
(37, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:16'),
(38, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:18'),
(39, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:20'),
(40, 'Optical Mouse', 'Dell', 'Nice functionality', 5, 5000, 25000, '2020-03-18 13:43:23');

-- --------------------------------------------------------

--
-- Table structure for table `bought_items`
--

CREATE TABLE `bought_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `date_bought` timestamp NOT NULL DEFAULT current_timestamp(),
  `seller_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bought_items`
--

INSERT INTO `bought_items` (`id`, `name`, `quantity`, `unit_price`, `total_price`, `date_bought`, `seller_id`) VALUES
(26, 'Book', 10, 500, 6000, '2020-03-16 23:47:29', 9),
(27, 'Book', 12, 500, 6000, '2020-03-16 23:48:29', 10);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `fname`, `lname`, `contact`) VALUES
(3, 'Claire', 'Nakimuli', '0759093836'),
(4, 'Henry', 'Suubi', '0775502474'),
(10, 'Brian', 'Angoda', '0775502474'),
(11, 'Charles', 'Dickens', '0775502474'),
(12, 'Vivian', 'Adebo', '0775502474');

-- --------------------------------------------------------

--
-- Table structure for table `repaired_items`
--

CREATE TABLE `repaired_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_cost` int(11) NOT NULL,
  `repair_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) DEFAULT NULL,
  `technician_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repaired_items`
--

INSERT INTO `repaired_items` (`id`, `name`, `description`, `quantity`, `total_cost`, `repair_date`, `customer_id`, `technician_id`) VALUES
(1, 'Laptop Charger', 'A dell laptop charger', 1, 10000, '2020-03-17 21:08:16', 10, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`id`, `fname`, `lname`, `contact`) VALUES
(9, 'frfrf', 'frfrfrf', 'frffrrf'),
(10, 'frfrf', 'frfrfrf', 'frffrrf');

-- --------------------------------------------------------

--
-- Table structure for table `sold_items`
--

CREATE TABLE `sold_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `date_sold` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sold_items`
--

INSERT INTO `sold_items` (`id`, `name`, `quantity`, `unit_price`, `total_price`, `date_sold`, `customer_id`) VALUES
(1, 'Optical Mouse', 1, 4000, 4000, '2020-03-19 06:00:55', 11),
(2, 'Book', 2, 500, 1000, '2020-03-19 07:24:40', 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `sex` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `contact`, `sex`, `type`, `password`, `reg_date`) VALUES
(1, 'Omara', 'Haggard', '', '', 'Male', 'Admin', '', '2020-03-17 21:32:23'),
(2, 'Brian', 'Chalie', 'brian@gmail.com', '0775502474', 'Male', 'Technician', '$2y$10$Z6o5u8u7MbEN4yTZ4Fs8OeqPyQPn8T2N7W5hcODSUyMA4bALMW/Au', '2020-03-17 22:37:10'),
(3, 'Akite', 'Viv', 'akite@gmail.com', '0775502474', 'Female', 'Technician', '$2y$10$yATUwy4.CzrrZxwD3fD54uJpr2voLv7UKXY83mUfeCZiyEQuB2Jje', '2020-03-17 22:38:38'),
(4, 'Akite', 'Ann', 'akite@gmail.com', '0775502474', 'Female', 'Technician', '$2y$10$xgZIsHOZpjwu61U9zmrDUuCQ3/kHXZKpX8xUZeknftXa3pUAIOZGW', '2020-03-17 22:43:51'),
(5, 'Brenda', 'Fassy', 'brenda@gmail.com', '0775502474', 'Female', 'Technician', '$2y$10$LKES.fOh0PBx42K/N1FjGuYiCjcvlPXly6PDEKmMVBhn7l3opESO2', '2020-03-17 22:48:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `added_items`
--
ALTER TABLE `added_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bought_items`
--
ALTER TABLE `bought_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repaired_items`
--
ALTER TABLE `repaired_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `technician_id` (`technician_id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sold_items`
--
ALTER TABLE `sold_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `added_items`
--
ALTER TABLE `added_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `bought_items`
--
ALTER TABLE `bought_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `repaired_items`
--
ALTER TABLE `repaired_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sold_items`
--
ALTER TABLE `sold_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bought_items`
--
ALTER TABLE `bought_items`
  ADD CONSTRAINT `bought_items_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`id`);

--
-- Constraints for table `repaired_items`
--
ALTER TABLE `repaired_items`
  ADD CONSTRAINT `repaired_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `repaired_items_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `sold_items`
--
ALTER TABLE `sold_items`
  ADD CONSTRAINT `sold_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
