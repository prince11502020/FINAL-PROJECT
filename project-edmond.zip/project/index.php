<!DOCTYPE html>
<html>
<head>
	<title>Computer Maintenance, Repair and Sales Management System</title>
	<link rel="stylesheet" type="text/css" href="resources/bootstrap/css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="resources/fontawesome/css/all.min.css">
<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
	<br><br>
<center>
<div class="container">

	<div class="row">
		<div class="col-md-12"><center><h5>COMPUTER SHOP IMS</h5></center></div>
	</div>
	<br>
	<center>
		<?php 
		if(isset($_GET['error']))
		{

			if($_GET['error'] == "emptyfields")
			{
				print('<p class="text-danger">Fill in all fields!</p>');
			}
			if($_GET['error'] == "invalidinputs")
			{
				print('<p class="text-danger">Email and password are invalid!</p>');
			}
			
		}


		 ?>
	</center>

	<form action="controller/login.ck.php" method="POST" class="frm">

		<br>
		<div class="row">
			<div class="col-md-12"><h4>Login</h4></div>
		</div>
		<br>
		
		<div class="row">
			<div class="col-md-6">Email</div>
			<div class="col-md-6"><input type="text" class="form-control" name="email" placeholder="Email" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">Password</div>
			<div class="col-md-6"><input type="Password" class="form-control" name="password" placeholder="Password" required=""></div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<button type="submit" name="login" class="form-control button btn-primary">Login</button>
			</div>
		</div>
		<a href="view/signup.php">New user? Create an account!</a>







	</form>

















	
</div> <!--Container ends here-->
</center>

<script src="resources/bootstrap/js/jquery.min.js"></script>
<script src="resources/bootstrap/js/popper.min.js"></script>
<script src="resources/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>