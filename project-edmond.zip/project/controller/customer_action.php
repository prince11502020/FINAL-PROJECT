<?php  
//action.php
$connect = mysqli_connect('localhost', 'root', '', 'fundibook');

$input = filter_input_array(INPUT_POST);

$first_name = mysqli_real_escape_string($connect, $input["fname"]);
$last_name = mysqli_real_escape_string($connect, $input["lname"]);
$contact   = mysqli_real_escape_string($connect, $input["contact"]);

if($input["action"] === 'edit')
{
 $query = "
 UPDATE customers 
 SET fname = '".$first_name."', 
 lname = '".$last_name."', 
 contact = '".$contact."'
 WHERE id = '".$input["id"]."'
 ";

 mysqli_query($connect, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM customers 
 WHERE id = '".$input["id"]."'
 ";
 mysqli_query($connect, $query);
}

echo json_encode($input);

?>
