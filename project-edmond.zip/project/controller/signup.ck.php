<?php 
require("../model/db.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

if(isset($_POST['signup']))
{


// Initialize some variables
$first_name = $last_name = $email = $gender = $contact = $pswd = $pswd2 = "";

$first_name = test_input($_POST['fname']);
$last_name = test_input($_POST['lname']);
$email = test_input($_POST['email']);
$contact = test_input($_POST['contact']);
$gender = test_input($_POST['gender']);
$pswd = $_POST['password'];
$pswd2 = $_POST['repeat-password'];

	if( empty($first_name) || empty($last_name) || empty($email) || empty($contact) || empty($gender) || empty($pswd) || empty($pswd2)  )
	{
		header("Location: ../view/signup.php?error=emptyfields");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $first_name)) 
	{
		header("Location: ../view/signup.php?error=invalidfname");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $last_name)) 
	{
		header("Location: ../view/signup.php?error=invalidlname");
		exit();
	}

	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
	{
		header("Location: ../view/signup.php?error=invalidemail");
		exit();
	}
	elseif (preg_match("/^[0-9]$/", $contact))
	{
			header("Location: ../view/signup.php?error=invalidcontact");
			exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $gender)) 
	{
		header("Location: ../view/signup.php?error=invalidgender");
		exit();
	}
	elseif($pswd !== $pswd2)
	{
		header("Location: ../view/signup.php?error=pswnotmatch");
		exit();
	}
	else
	{
		// Block runs when the validation is done
		$first_name = mysqli_real_escape_string($conn, $first_name);
		$last_name = mysqli_real_escape_string($conn,$last_name);
		$email = mysqli_real_escape_string($conn, $email);
		$contact = mysqli_real_escape_string($conn,$contact);
		$gender = mysqli_real_escape_string($conn, $gender);
	    $type = "Technician";
		try 
		{
			// Hash the password

			$pswd = password_hash($pswd, PASSWORD_DEFAULT);
			$sql = "INSERT INTO users(fname, lname, email, contact, sex, type, password) VALUES (?,?,?,?,?,?,?) ";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param("sssssss", $first_name, $last_name, $email, $contact, $gender, $type , $pswd);
			$stmt->execute();
			if($stmt)
			{
				$query = "SELECT * FROM users WHERE email = ? AND contact = ?";
				$result = $conn->prepare($query);
				$result->bind_param("ss", $email, $contact);
				$result->execute();
				$rows = $result->get_result(); 
				if(!$result->num_rows > 0)
				{
					$id = $fname = $lname = $phone = "";

					while($row = $rows->fetch_assoc())
					{
						$id = $row['id'];
						$fname = $row['fname'];
						$lname = $row['lname'];
					}

					session_start();
					$_SESSION['user_id'] = $id;
					$_SESSION['first_name'] = $fname;
					$_SESSION['last_name'] = $lname;
					header("Location: ../view/dashboard.php?msg=loginsuccess");
					exit();



				}
				else
				{
					header("Location: ../view/signup.php?msg=regerror");
					exit();
				}





			}






		} 
		catch (Exception $e) 
		{
			print("The error is: ".$e->getMessage());
			exit();
		}









	}










}
else
{

	print("Signup form not submitted");
	exit();
}











$result->close();
$stmt->close();


$conn->close();
 ?>