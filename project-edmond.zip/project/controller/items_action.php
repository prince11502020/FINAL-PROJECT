<?php  
//action.php
$connect = mysqli_connect('localhost', 'root', '', 'fundibook');

$input = filter_input_array(INPUT_POST);

$name = mysqli_real_escape_string($connect, $input["name"]);
$specification = mysqli_real_escape_string($connect, $input["specification"]);
$description   = mysqli_real_escape_string($connect, $input["description"]);
$quantity  = mysqli_real_escape_string($connect, $input["quantity"]);
$unit_price   = mysqli_real_escape_string($connect, $input["unit_price"]);
$total_price   = mysqli_real_escape_string($connect, $input["total_price"]);
$date_added   = mysqli_real_escape_string($connect, $input["date_added"]);

if($input["action"] === 'edit')
{
 $query = "
 UPDATE added_items 
 SET name = '".$name."', 
 specification = '".$specification."', 
 description = '".$description."',
 quantity = '".$quantity."',
 unit_price = '".$unit_price."',
 total_price = '".$total_price."',
 date_added = '".$date_added."'
 WHERE id = '".$input["id"]."'
 ";

 mysqli_query($connect, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM added_items 
 WHERE id = '".$input["id"]."'
 ";
 mysqli_query($connect, $query);
}

echo json_encode($input);

?>
