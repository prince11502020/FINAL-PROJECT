 <?php



 function fix_string($data)
 {

$pats = array(
'/([.!?]\s{2}),/', # Abc.  ,Def
'/\.+(,)/',        # ......,
'/(!)!+/',         # abc!!!!!!!!
'/\s+(,)/',        # abc   , def
'/([a-zA-Z])\1\1/');      # greeeeeeen

$fixed = preg_replace($pats, '$1', $data);
$really_fixed = preg_replace('/,(?!\s)/', ', ', $fixed);

return $really_fixed;

 }



?>
