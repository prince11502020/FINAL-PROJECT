<?php 
// Include the database connection file
require('../model/db.php');
//require("string_sanizer.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

// Check for set global variables from add_items.php file

echo "You are here!<br>";

if(isset($_POST['submit']))
{
	$item = $specification = $description = $quantity = $unit_price = "";

	$item = test_input($_POST['name']);
	$specification = test_input($_POST['specification']);
	$description = test_input($_POST['description']);
	$quantity = test_input($_POST['quantity']);
	$unit_price = test_input($_POST['unit-price']);

	// Check for empty fields

	if( empty($item) || empty($specification)  || empty($description) || empty($quantity) || empty($unit_price)  )
	{
		header("Location: ../view/add_item.php?error=emptyfields");
		exit();
	}
	elseif (preg_match("/[^A-Za-z'-'_' ']/", $item))
	{
		header("Location: ../view/add_item.php?error=invaliditemname");
		exit();
	}
	elseif (preg_match("/[^A-Za-z'-'_' ']/", $specification))
	{
		header("Location: ../view/add_item.php?error=invalidspecification");
		exit();
	}
	elseif (preg_match("/[^A-Za-z'-'_' ']/", $description))
	{
		header("Location: ../view/add_item.php?error=invaliddescription");
		exit();
	}
	elseif (!preg_match('/^\d+$/', $quantity))
	{
		header("Location: ../view/add_item.php?error=invalidquantity");
		exit();
	}
	elseif (!preg_match('/^\d+$/', $unit_price))
	{
		header("Location: ../view/add_item.php?error=invalidunit_price");
		exit();
	}
	elseif (($quantity % 1) != "0")
	{
		header("Location: ../view/add_item.php?error=low_qty");
		exit();
	}
	else
	{

		$item 		   = mysqli_real_escape_string($conn, $item );
		$specification = mysqli_real_escape_string($conn, $specification);
		$description   = mysqli_real_escape_string($conn, $description);
		$quantity      = mysqli_real_escape_string($conn, $quantity);
		$unit_price    = mysqli_real_escape_string($conn, $unit_price);
		$total_price = $unit_price * $quantity;
		try 
		{
			$sql = "INSERT INTO added_items(name, specification, description, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?)";
		    $stmt = $conn->prepare($sql);
		    $stmt->bind_param("sssiii", $item, $specification, $description, $quantity, $unit_price, $total_price);
		    $stmt->execute();
		    header("Location: ../view/add_item.php?msg=itemadded");
		    exit();

		} 
		catch (Exception $e) 
		{
			echo "Error message: <b>".$e->getMessage()."</b>";
			exit();
		}

		


	}

	
 

}
else
{

	print("Form was not submitted");
	exit();

}

// Close the statement
$stmt->close();

// Close connection to the database
$conn->close();

 ?>