
<?php 
session_start();

require("../model/db.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if(isset($_POST['submit']))
{

	$name = $description  = $cust_fname = $cust_lname = $contact = "";
    $quantity = 0;
    $repair_cost = 0 ;
    $name 		 = test_input($_POST['name']);
    $description = test_input($_POST['description']);
    $quantity    = test_input($_POST['quantity']);
    $repair_cost = test_input($_POST['repair-costs']);
    $cust_fname  = 	test_input($_POST['cust-fname']);
    $cust_lname  = test_input($_POST['cust-lname']);
    $contact	 = test_input($_POST['contact']);

    if ( empty($name) || empty($description) || empty($quantity) || empty($repair_cost) || empty($cust_fname) || empty($cust_lname) || empty($contact) ) 
    {
    	header("Location: ../view/repair_item.php?error=emptyfields");
    	exit();
    }
    elseif (preg_match("/[^A-Za-z'-'_' ']/", $name))
    {
    	header("Location: ../view/repair_item.php?error=invalidname");
    	exit();
    }
    elseif (preg_match("/[^A-Za-z'-'_' ']/", $description))
    {
    	header("Location: ../view/repair_item.php?error=invaliddescription");
    	exit();
    }
    elseif (!preg_match('/^\d+$/', $quantity))
    {
    	header("Location: ../view/repair_item.php?error=invalidquantity");
    	exit();
    }
    elseif (($quantity % 1) != "0")
    {
    	header("Location: ../view/repair_item.php?error=invalidquantity");
    	exit();
    }
    elseif (!preg_match('/^\d+$/', $repair_cost))
    {
    	header("Location: ../view/repair_item.php?error=invalidrepaircost");
    	exit();
    }
    elseif (($repair_cost % 1) != "0")
    {
    	header("Location: ../view/repair_item.php?error=invalidrepaircost");
    	exit();
    }
     elseif (!preg_match("/^[a-zA-Z]*$/", $cust_fname))
	{
		header("Location: ../view/repair_item.php?error=invalidfname");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $cust_lname))
	{
		header("Location: ../view/repair_item.php?error=invalidlname");
		exit();
	}
	elseif (preg_match("/^[0-9]$/", $contact))
	{
		header("Location: ../view/repair_item.php?error=invalidcontact");
		exit();
	}
	else
	{

		$name 		 = mysqli_real_escape_string($conn, $name);
		$description = mysqli_real_escape_string($conn, $description);
		$quantity    = mysqli_real_escape_string($conn, $quantity);
		$repair_cost = mysqli_real_escape_string($conn, $repair_cost);
		$cust_fname  = mysqli_real_escape_string($conn, $cust_fname);
		$cust_lname  = mysqli_real_escape_string($conn, $cust_lname);
		$contact	 = mysqli_real_escape_string($conn, $contact);

		$item_id = $cust_id = "";
		try
		{
			// Block to insert customers details
           
			$sql  = "INSERT INTO customers(fname, lname, contact) VALUES (?,?,?)";
	  		$stmt = $conn->prepare($sql);
	  		$stmt->bind_param("sss", $cust_fname, $cust_lname, $contact );
	  		$stmt->execute();
	  		// If the query executes successfully
	  		if($stmt)
	  		{
	  			// Get the id of the customer

	  			$connect = mysqli_connect("localhost", "root", "", "fundibook");
			    $query = "SELECT * FROM customers ORDER BY id DESC LIMIT 1";
				$result = mysqli_query($connect, $query);
				while($row = mysqli_fetch_array($result))
			     {
			      $cust_id= $row['id'];
			     }


	  		}
	  		$stmt->close();

		}
		catch(Exception $e)
		{

			print("The error is: ".$e->getMessage());
			exit();
		}

		try 
		{
			// Block to insert item details

			$sql  = "INSERT INTO repaired_items(name, description, quantity, total_cost, customer_id) VALUES (?,?,?,?,?)";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param("ssiii", $name, $description, $quantity, $repair_cost, $cust_id);
			$stmt->execute();

			// if the query executes

			if($stmt)
			{
				// Get the id of last repaired item


				$connect = mysqli_connect("localhost", "root", "", "fundibook");
			    $query = "SELECT * FROM repaired_items ORDER BY id DESC LIMIT 1";
				$result = mysqli_query($connect, $query);
				while($row = mysqli_fetch_array($result))
			     {
			      $item_id = $row['id'];
			     }

			}



		} 
		catch (Exception $e) 
		{	
			print("The error is: ".$e->getMessage());
			exit();

		}

		// Create a try block to update the technician_id of the repaired item



	}



}
else
{
	print("Form not submitted");
	exit();
}


// Close the connection
$conn->close();

 ?>