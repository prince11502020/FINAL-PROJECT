<?php 
require("../model/db.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if (isset($_POST['submit'])) 
{
	
$name = $specification = $description = $unit_price = $seller_fname = $seller_lname = $contact = "";
$quantity = 0;
$unit_price = 0;
$name = test_input($_POST['name']); 
$specification = test_input($_POST['specification']);
$description = test_input($_POST['description']);
$quantity = test_input($_POST['quantity']);
$unit_price = test_input($_POST['unit-price']);
$seller_fname = test_input($_POST['seller-fname']);
$seller_lname = test_input($_POST['seller-lname']);
$contact = test_input($_POST['contact']);

if( empty($name) || empty($specification) || empty($description) || empty($quantity)
 || empty($unit_price) || empty($seller_fname) || empty($seller_lname) || empty($contact))
 {

 	header("Location: ../view/buy_item.php?error=emptyfields");
 	exit();

 }
 elseif (preg_match("/[^A-Za-z'-'_' ']/", $name))
	{
		header("Location: ../view/buy_item.php?error=invaliditemname");
		exit();
	}
	elseif (preg_match("/[^A-Za-z'-'_' ']/", $specification))
	{
		header("Location: ../view/buy_item.php?error=invalidspecification");
		exit();
	}
	elseif (preg_match("/[^A-Za-z'-'_' ']/", $description))
	{
		header("Location: ../view/buy_item.php?error=invaliddescription");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $seller_fname))
	{
		header("Location: ../view/buy_item.php?error=invalidsfname");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $seller_lname))
	{
		header("Location: ../view/buy_item.php?error=invalidlfname");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z]*$/", $contact))
	{
		header("Location: ../view/buy_item.php?error=invalidcontact");
		exit();
	}
	elseif (!preg_match('/^\d+$/', $quantity))
	{
		header("Location: ../view/buy_item.php?error=invalidquantity");
		exit();
	}
	elseif (!preg_match('/^\d+$/', $unit_price))
	{
		header("Location: ../view/buy_item.php?error=invalidunit_price");
		exit();
	}
	elseif (($quantity % 1) != "0")
	{
		header("Location: ../view/buy_item.php?error=low_qty");
		exit();
	}
	else
	{

		$name = mysqli_real_escape_string($conn, $name ); 
		$specification = mysqli_real_escape_string($conn, $specification ); 
		$description = mysqli_real_escape_string($conn, $description ); 
		$quantity = mysqli_real_escape_string($conn, $quantity ); 
		$unit_price = mysqli_real_escape_string($conn, $unit_price ); 
		$seller_fname = mysqli_real_escape_string($conn, $seller_fname); 
		$seller_lname = mysqli_real_escape_string($conn, $seller_lname); 
		$contact = mysqli_real_escape_string($conn, $contact);

		$total_price = 0;
		$total_price = ($quantity * $unit_price); 


		$item_id = $seller_id = "";
		try 
		{

			$sql = "INSERT INTO bought_items(name, quantity, unit_price, total_price) VALUES (?,?,?,?) ";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param("siii", $name, $quantity, $unit_price, $total_price);
			$stmt->execute();


			$connect = mysqli_connect("localhost", "root", "", "fundibook");
			$query = "SELECT * FROM bought_items ORDER BY id DESC LIMIT 1";
			$result = mysqli_query($connect, $query);
			while($row = mysqli_fetch_array($result))
		     {
		      $item_id = $row['id'];
		     }

			
			
		} 
		catch (Exception $e) 
		{
			print("Failed to insert, error: <b>".$e->getMessage()."</b>");
			exit();
		}
		finally
		{
			echo "Bought items insert block";
		}
		
		try 
		{
		    
			$sql2 = "INSERT INTO sellers(fname, lname, contact) VALUES (?,?,?)";
			$stmt = $conn->prepare($sql2);	
			$stmt->bind_param("sss", $seller_fname, $seller_lname, $contact);
			$stmt->execute();
			
			$connect = mysqli_connect("localhost", "root", "", "fundibook");
			$query = "SELECT * FROM sellers ORDER BY id DESC LIMIT 1";
			$result = mysqli_query($connect, $query);
			while($row = mysqli_fetch_array($result))
		     {
		      $seller_id = $row['id'];
		     }
			

		} 
		catch (Exception $e) 
		{
			print("Failed to insert seller and get last id, error: <b>".$e->getMessage()."</b>");
			exit();
		}


		try
		{

			$sql = "UPDATE bought_items SET seller_id = ? WHERE id=?";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param("ss", $seller_id, $item_id);
			$stmt->execute();
			if($stmt)
			{
				header("Location: ../view/buy_item.php?msg=itembought");
		        exit();
			}



		}
		catch(Exception $ex)
		{
			print("Failed to update seller_id in bought items table, error: <b>".$e->getMessage()."</b>");
			exit();
		}

		



	}



}

$stmt->close();

$conn->close();

 ?>