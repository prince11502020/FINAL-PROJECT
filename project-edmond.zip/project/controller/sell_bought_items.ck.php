<?php 

require("../model/db.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if(isset($_POST['sell-item']))
{

	# item-id
# item-quantity
 # unit-price
	/*
	first-name
    last-name
    contact
	*/
$item_id = $item_qty = $unit_price = "";
$cust_fname = $cust_lname = $cust_contact = "";

$item_id = test_input($_POST['item-id']);
$item_qty = test_input($_POST['item-quantity']);
$unit_price = test_input($_POST['unit-price']);

$cust_fname = test_input($_POST['first-name']);
$cust_lname =  test_input($_POST['last-name']);
$cust_contact = test_input($_POST['contact']);


				if ( empty($item_id) || empty($item_qty) || empty($unit_price) || empty($cust_fname) || empty($cust_lname) || empty($cust_contact) ) 
				{
					header("Location: ../view/sell_bought_items.php?error=emptyfields");
					exit();
				}
				elseif(!preg_match('/^\d+$/', $item_id))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidid");
					exit();

				}
				elseif(!preg_match('/^\d+$/', $item_qty))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidqty");
					exit();

				}
				elseif(!preg_match('/^\d+$/', $unit_price))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidprice");
					exit();

				}
				elseif (!preg_match("/^[a-zA-Z]*$/", $cust_fname))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidfname");
					exit();
				}
				elseif (!preg_match("/^[a-zA-Z]*$/", $cust_lname))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidlname");
					exit();
				}
				elseif (preg_match("/^[0-9]$/", $cust_contact))
				{
					header("Location: ../view/sell_bought_items.php?error=invalidcontact");
					exit();
				}
				else
				{

					$item_id	 = mysqli_real_escape_string($conn, $item_id);
					$item_qty 	 = mysqli_real_escape_string($conn, $item_qty);
					$unit_price  = mysqli_real_escape_string($conn, $unit_price);


					$cust_fname    = mysqli_real_escape_string($conn, $cust_fname);
					$cust_lname    =  mysqli_real_escape_string($conn, $cust_lname);
					$cust_contact  = mysqli_real_escape_string($conn, $cust_contact);

					try 
					{

							$sql = "SELECT * FROM bought_items WHERE id = ?";
							$stmt = $conn->prepare($sql);
							$stmt->bind_param("s", $item_id);
							$stmt->execute();
							$result = $stmt->get_result();
							if($result->num_rows < 1)
							{
								header("Location: ../view/sell_bought_items.php?error=noitem");
								exit();

							}
							else
							{	
								// Collect 




								$item_name = "";
								$stock_qty = 0;

								while($row = $result->fetch_assoc())
								{
									$stock_qty = $row['quantity'];
									$item_name = $row['name'];
								}

								// Check if there are enough or more items requested for

								if($stock_qty < $item_qty)
								{
									header("Location: ../view/sell_bought _items.php?error=notenoughitems".$stock_qty);
								    exit();
								}
								elseif($item_qty < 1)
								{
									header("Location: ../view/sell_bought_items.php?error=invaliditemqty");
								    exit();
								}
								elseif($unit_price < 0)
								{
									header("Location: ../view/sell_bought_items.php?error=invalidunitprice");
								    exit();
								}
								else
								{
									try 
									{
										$sql = "INSERT INTO customers(fname, lname, contact) VALUES (?,?,?)";
										$stmt = $conn->prepare($sql);
										$stmt->bind_param("sss", $cust_fname, $cust_lname, $cust_contact );
										$stmt->execute();

										if($stmt)
										{
											$cust_id = "";
											// Block to run if the customer details are inserted

											// Get the id of the last inserted customer

											$connect = mysqli_connect("localhost", "root", "", "fundibook");
										    $query = "SELECT * FROM customers ORDER BY id DESC LIMIT 1";
											$result = mysqli_query($connect, $query);

											while($row = mysqli_fetch_array($result))
										     {
										      	$cust_id = $row['id'];
										     }

										     // Then update the added_items table  details

										     try
										     {

										     	$new_stock_qty = 0; // new quantity to add to added_items table

										     	// Compute the new added_items quantity

										     	$new_stock_qty = $stock_qty - $item_qty;

										     	$sql = "UPDATE bought_items SET quantity = ? WHERE id = ?";
										     	$stmt = $conn->prepare($sql);
										     	$stmt->bind_param("ii", $new_stock_qty, $item_id );
										     	$stmt->execute();

										     	if(!$stmt)
										     	{
										     		echo "Failed to update new stock quantity for bought items";
										     		exit();
										     	}
										     	else
										     	{

										     		// Now we insert sold item into the sold items table

										     		try 
										     		{
										     			// Compute the total price of the sold item

										     			$total_price = $unit_price * $item_qty;
										     			$query = "INSERT INTO sold_items(name, quantity, unit_price, total_price, customer_id) 
										     			VALUES (?,?,?,?,?)";
										     			$stmt = $conn->prepare($query);
										     			$stmt->bind_param("siiii", $item_name, $item_qty, $unit_price, $total_price, $cust_id);
										     			$stmt->execute();

										     			// check to make sure the item was inserted

										     			if(!$stmt)
										     			{
										     				print("Failed to insert item details into sold_items table");
										     				exit();
										     			}
										     			else
										     			{
										     				//  Redirect to the sell items page 

										     				header("Location: ../view/sell_bought_items.php?msg=salessuccess");
										     				exit();
										     			}


										     		} 
										     		catch (Exception $e) 
										     		{
										     			echo $e->getMessage();
										     			exit();
										     		}
										     		finally
										     		{
										     			echo "Block to insert sold item details into sold_items table";
										     			exit();
										     		}


										     	}





										     }
										     catch(Exception $e)
										     {

										     	echo "Error message is: ".$e->getMessage();
										     	exit();

										     }





										}
										else
										{
											print("Customer details not inserted");
											exit();
										}




									} 
									catch (Exception $e) 
									{
										echo "Error: ".$e->getMessage();
										exit();
									}
									

								}



							}


					} 
					catch (Exception $e) 
					{
						echo "Error message is: ".$e->getMessage();
						exit();
					}


				}




}
else
{
	print("Form was not submitted");
	exit();
}




$stmt->close();

$conn->close();
 ?>