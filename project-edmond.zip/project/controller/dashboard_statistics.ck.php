<?php 
require("../model/db.php");

// This script queries fundibook's database tables for summaries of certain fields


# Summary for sold items
try 
{
	$sold_items = 0;
	// Block to query total number of sold items
	$query = "SELECT COUNT(*) AS sold_items FROM sold_items ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$sold_items = $row['sold_items'];
	}

	//echo $sold_items." sold items!<br>";



} 
catch (Exception $e) 
{

 echo "Sold items statistics error: ".$e->getMessage();
 exit();
	
}


# Summary for added items
try 
{
	$added_items = 0;
	// Block to query total number of added items
	$query = "SELECT COUNT(*) AS added_items FROM added_items ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$added_items = $row['added_items'];
	}

	//echo $added_items." added items!<br>";



} 
catch (Exception $e) 
{

 echo "Added items statistics error: ".$e->getMessage();
 exit();
	
}


# Summary for bought items
try 
{
	$bought_items = 0;
	// Block to query total number of bought items
	$query = "SELECT COUNT(*) AS bought_items FROM bought_items ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$bought_items = $row['bought_items'];
	}

	//echo $bought_items." bought items!<br>";



} 
catch (Exception $e) 
{

 echo "Bought items statistics error: ".$e->getMessage();
 exit();
	
}


# Summary for repaired items
try 
{
	$repaired_items = 0;
	// Block to query total number of bought items
	$query = "SELECT COUNT(*) AS repaired_items FROM repaired_items ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$repaired_items = $row['repaired_items'];
	}

	//echo $repaired_items." repaired items!<br>";



} 
catch (Exception $e) 
{

 echo "Repaired items statistics error: ".$e->getMessage();
 exit();
	
}


# Summary for customers
try 
{
	$customers = 0;
	// Block to query total number of bought items
	$query = "SELECT COUNT(*) AS customers FROM customers ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$customers = $row['customers'];
	}

	//echo $customers." customers!<br>";



} 
catch (Exception $e) 
{

 echo "Customers statistics error: ".$e->getMessage();
 exit();
	
}


# Summary for sellers
try 
{
	$sellers = 0;
	// Block to query total number of bought items
	$query = "SELECT COUNT(*) AS sellers FROM sellers ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$sellers = $row['sellers'];
	}

	//echo $sellers." sellers!<br>";



} 
catch (Exception $e) 
{

 echo "Sellers statistics error: ".$e->getMessage();
 exit();
	
}

# Summary for users
try 
{
	$users = 0;
	// Block to query total number of bought items
	$query = "SELECT COUNT(*) AS users FROM users ";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	$results  = $stmt->get_result();
	
	while( $row = $results->fetch_assoc() )
	{
		$users = $row['users'];
	}

	//echo $users." users!<br>";



} 
catch (Exception $e) 
{

 echo "Users statistics error: ".$e->getMessage();
 exit();
	
}











$stmt->close();

$conn->close();


 ?>