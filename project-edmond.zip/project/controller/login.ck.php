<?php 
require("../model/db.php");

// function to validate input
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

if(isset($_POST['login']))
{

$email = $password = "";
$email = test_input($_POST['email']);
$password = $_POST['password'];

		if( empty($email) || empty($password) )
		{
			header("Location: ../index.php?error=emptyfields");
			exit();
		}
		elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			header("Location: ../index.php?error=invalidinputs");
			exit();
		}
		else
		{

			$email = mysqli_real_escape_string($conn, $email);

			try 
			{

				$sql = "SELECT * FROM users WHERE email = ?";

				$stmt = $conn->prepare($sql);
				$stmt->bind_param("s", $email);
				$stmt->execute();
				$results = $stmt->get_result();
				if(!$results->num_rows > 0)
				{
					header("Location: ../index.php?error=invalidinputs");
			        exit();
				}
				else
				{

					$id = $first_name = $last_name = $pass = "";
					
					 while($row = $results->fetch_assoc())
					 {
					 	$id = $row['id'];
					 	$first_name = $row['fname'];
					 	$last_name = $row['lname'];
					 	$pass = $row['password'];

					 }


					 if(!password_verify($password, $pass))
					 {
					 	header("Location: ../index.php?error=invalidinputs");
			            exit();
					 }
					 else
					 {

				        session_start();
				        $_SESSION['user_id'] = $id;
						$_SESSION['first_name'] = $fname;
						$_SESSION['last_name'] = $lname;
				        header("Location: ../view/dashboard.php?login=success");
					 	exit();


					 }

				}

				
			} 
			catch (Exception $e) 
			{
				print("The error is: ".$e->getMessage());
			    exit();
			}



		}


}
else
{

 print("Form was not submitted!");
 exit();
}

$stmt->close();
$conn->close();

 ?>